MP4 Part IV clean artifact bundle.

Contents:

- `code/`: current source snapshots for the Part IV scripts.
- `part4_changes.patch`: patch file for the Part IV script changes only.
- `traces/`: simulation outputs grouped by task.

Notes:

- The patch intentionally includes only `run_pd_disagg.py`, `sweep_pd_allocation.py`, and `sweep_kv_bandwidth.py`.
- The GPT-OSS KV-cache dispatch fix was moved into `run_pd_disagg.py`, so no core library change is required for this submission bundle.
